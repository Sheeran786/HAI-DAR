# HAI-DAR Wholesale App — Developer Handover

Mobile-first B2B wholesale ordering app for the Indian hand-tool brand **HAI-DAR**. Customers browse a factory catalogue, drop items in a bulk cart, send WhatsApp/inbox enquiries, place bulk orders, and track them by status. A protected admin control room manages products, orders, enquiries and business settings — everything reads/writes the same MongoDB.

> Brand direction: RED (`#D21414`) + BLACK (`#111111`) on white. Industrial, factory-direct, never pastel. Do not repaint the UI.

---

## 1. Tech stack

| Layer     | Tech                                                                                       |
| --------- | ------------------------------------------------------------------------------------------ |
| Frontend  | Expo SDK 54, React Native 0.86, TypeScript, Expo Router, `@expo/vector-icons`              |
| Backend   | FastAPI, Motor (async MongoDB), PyJWT (HS256), passlib\[bcrypt] 1.7.4 + bcrypt 4.3.0       |
| Database  | MongoDB (any 6.x / 7.x). Single database, six collections (see §4)                         |
| Auth      | Custom JWT — customer via OTP (mock), admin via email + bcrypt-hashed password stored in DB |
| Storage   | `@/src/utils/storage` wrapper (secure store on native, `localStorage` on web)              |

Everything is served by two processes: **FastAPI on port 8001** (`/api/*`) and **Expo Metro** for the RN client.

---

## 2. Repository layout

```
/app
├── backend
│   ├── server.py               # ALL FastAPI routes + Mongo access (single file)
│   ├── requirements.txt
│   ├── pytest.ini
│   ├── tests/
│   │   ├── backend_test.py     # e2e API tests (19)
│   │   └── test_admin_auth.py  # admin auth tests (19)
│   ├── .env.template           # copy → .env
│   └── .env                    # LOCAL ONLY, never commit
├── frontend
│   ├── app/                    # Expo Router routes
│   │   ├── _layout.tsx         # root layout + font/icon prewarm — DO NOT modify prewarm logic
│   │   └── index.tsx           # ALL screens (splash/home/products/detail/cart/enquiry/orders/profile/admin)
│   ├── src/
│   │   ├── theme.ts            # colors + makeStyles + useTheme (design tokens)
│   │   ├── haidar-api.ts       # typed API client (fetch wrapper + shared types)
│   │   └── utils/storage/      # cross-platform key-value + secure store wrapper
│   ├── assets/                 # images/fonts/icons
│   ├── scripts/                # expo helpers
│   ├── app.json                # Expo config (bundle id, permissions, splash, icon)
│   ├── package.json
│   ├── metro.config.js         # DO NOT modify — required by Expo
│   ├── tsconfig.json, eslint.config.js
│   ├── .env.template
│   └── .env
├── memory/
│   ├── PRD.md                  # product brief
│   └── test_credentials.md     # LOCAL ONLY, never commit
├── HANDOVER.md                 # this file
└── README.md
```

Emergent-managed files (do not edit): `/app/frontend/eas.json` (only exists on Emergent), `/app/frontend/metro.config.js`, and the `EXPO_PACKAGER_*` env keys.

---

## 3. Runtime architecture

```
┌───────────────────────┐   HTTPS   ┌────────────────────────┐   Motor    ┌──────────────┐
│  Expo / React Native  │ ────────► │  FastAPI /api/*        │ ─────────► │   MongoDB    │
│  (mobile + web build) │           │  (Uvicorn, port 8001)  │            │              │
└───────────────────────┘           └────────────────────────┘            └──────────────┘
```

The frontend never talks to Mongo directly; it always goes through `/api/*`. Backend responses always exclude Mongo's `_id`.

---

## 4. Database schema

Single database (name from `DB_NAME`). All collections use a UUID `id` string field for public references; `_id` is never returned to clients.

### `products`
```jsonc
{
  "id": "uuid-v4",
  "name": "HAI-DAR Sledge Hammer",
  "category": "Sledge Hammer",
  "sku": "HD-SH-001",
  "description": "Heavy-duty forged carbon-steel sledge hammer ...",
  "specifications": ["Drop-forged head", "Hickory-style handle"],
  "packaging": "Poly-wrapped, 6 units per master carton",
  "delivery": "Dispatched in 3–5 working days ...",
  "image_data": [],                       // reserved for future image URLs
  "variants": [                           // 1..N per product
    { "id": "uuid", "label": "2 LB", "sku": "HD-SH-2LB",
      "weight": "2 lb", "moq": 12, "wholesale_price": 340, "stock": 240 }
  ],
  "featured": true,
  "is_new": false,
  "active": true,
  "badge": "FACTORY DIRECT",
  "created_at": "2026-…Z"
}
```

### `settings` (single doc, id = "business")
```jsonc
{
  "id": "business",
  "whatsapp": "919999999999",
  "phone": "+91 ...",
  "email": "sales@haidartools.in",
  "address": "Factory address ...",
  "delivery_info": "Pan India dispatch ...",
  "announcement": "Factory-direct wholesale supply across India"
}
```

### `customers`
```jsonc
{ "id": "uuid", "mobile": "9999999999", "name": "", "business_name": "",
  "city": "", "state": "", "created_at": "…Z" }
```

### `admins` (unique index on `email`)
```jsonc
{ "id": "uuid", "email": "admin@haidartools.in",
  "password_hash": "$2b$12$…",             // bcrypt, never returned
  "created_at": "…Z" }
```

### `orders`
```jsonc
{
  "id": "HD-YYMMDD-XXXX",                  // human-readable
  "customer_id": "uuid",
  "items": [
    { "product_id": "uuid", "name": "HAI-DAR Sledge Hammer",
      "variant": "2 LB", "quantity": 24, "price": 340 }
  ],
  "customer_name": "", "business_name": "", "mobile": "",
  "total": 8160,
  "status": "Enquiry Received",            // see §7
  "tracking": "",
  "created_at": "…Z"
}
```

### `enquiries`
```jsonc
{
  "id": "HD-ENQ-YYMMDD-XXXX",
  "customer_id": "uuid | ''",              // '' when the bulk-enquiry form is used anonymously
  "customer_name": "", "business_name": "",
  "mobile": "", "whatsapp": "", "city": "", "state": "",
  "product": "HAI-DAR Sledge Hammer",
  "required_quantity": 200,
  "message": "…",
  "items": [ /* optional, same shape as order items when triggered from a product */ ],
  "status": "Enquiry Received",
  "sales_response": "",
  "sales_notes": "",
  "created_at": "…Z"
}
```

### `otp_codes`
Vestigial from the mock OTP flow — one doc per mobile, safe to ignore or wipe.

### Relationships
- `orders.customer_id` → `customers.id`
- `enquiries.customer_id` → `customers.id` (nullable/empty for guest form)
- `orders.items[].product_id` → `products.id`
- `products.variants[]` is embedded (no separate collection)
- Admin routes gate on `admins._id` implicit via JWT `sub` claim

---

## 5. Authentication & authorization

Tokens are HS256 JWT with 14-day expiry, signed with `JWT_SECRET`. Payload:
```json
{ "sub": "<user id or admin id>", "role": "customer" | "admin", "exp": … }
```

### Customer OTP (development mock)
1. `POST /api/auth/request-otp?mobile=<10 digits>` — always returns `{ "message": "...", "dev_code": "1234" }`. No SMS is sent.
2. `POST /api/auth/verify-otp?mobile=<10 digits>&code=<4 digits>` — accepts **any 4-digit numeric** code, upserts a `customers` row keyed on mobile, returns `{ token, user }`.
3. The frontend stores the token in `storage.secureSet("haidar.customer.token", ...)` so the session survives reloads.

### Admin (DB-backed)
- Seeded on backend startup if `admins` is empty: uses `ADMIN_EMAIL` + `ADMIN_PASSWORD` env vars; if `ADMIN_PASSWORD` is empty the backend generates `secrets.token_urlsafe(18)`, logs it once, and writes it to `/app/memory/test_credentials.md`.
- `POST /api/auth/admin-login?email=&password=` — looks up admin by lower-cased email, runs `passlib` bcrypt verify against a **dummy hash** when the email is unknown so response time does not leak enumeration; returns `{ token, role: "admin" }` on success, `401 "Incorrect email or password"` otherwise.
- Frontend stores the admin token separately (`haidar.admin.token`) so buyer + admin can coexist on the same device.

### Route guards
Backend dependencies:
- `current_identity` — accepts any customer/admin JWT (used on `/api/orders`, `/api/enquiries`, order/enquiry detail).
- `admin_identity` — requires `role == "admin"` (used on every `/api/admin/*` route).

Anonymous → 401. Wrong role → 403. Customers can only read their own orders/enquiries because the query is scoped to `customer_id = identity.sub`.

---

## 6. API surface

All routes are under `/api` (Kubernetes ingress rewrites `/api/*` to port 8001 in the Emergent preview).

### Public
| Method | Path | Notes |
| ------ | ---- | ----- |
| GET  | `/api/`                    | Health check |
| GET  | `/api/settings`            | Returns the single business settings doc |
| GET  | `/api/products`            | Query params: `search`, `category`, `sort` (`price_asc\|price_desc\|newest`), `page`, `page_size` |
| GET  | `/api/products/{id}`       | Single product |
| POST | `/api/auth/request-otp`    | Query `mobile` |
| POST | `/api/auth/verify-otp`     | Query `mobile`, `code` |
| POST | `/api/auth/admin-login`    | Query `email`, `password` |
| POST | `/api/enquiries`           | Body: enquiry — creates a bulk enquiry (works signed-in or anonymous) |

### Customer (JWT required)
| Method | Path | Notes |
| ------ | ---- | ----- |
| GET  | `/api/orders`                     | List of caller's orders |
| POST | `/api/orders`                     | Create order from cart; returns full order doc |
| GET  | `/api/orders/{id}`                | Detail — caller must own it |
| GET  | `/api/enquiries`                  | List of caller's enquiries |
| GET  | `/api/enquiries/{id}`             | Detail — caller must own it |

### Admin (admin JWT required)
| Method | Path | Notes |
| ------ | ---- | ----- |
| GET / POST / PATCH / DELETE | `/api/admin/products` (+ `/{id}`)   | Full product CRUD |
| GET                         | `/api/admin/orders`                 | Full queue |
| PATCH                       | `/api/admin/orders/{id}`            | Update `status`, `tracking` (+ any allowed field) |
| GET                         | `/api/admin/enquiries`              | Full queue |
| PATCH                       | `/api/admin/enquiries/{id}`         | Update `status`, `sales_response`, `sales_notes` |
| GET                         | `/api/admin/settings`               | Same doc as public but authenticated |
| PATCH                       | `/api/admin/settings`               | Update WhatsApp/phone/email/address/announcement |

Every request/response uses JSON. Auth is via `Authorization: Bearer <token>` header.

---

## 7. Order & enquiry status pipeline

Six stages, in order:

```
Enquiry Received → Order Confirmed → Processing → Packed → Dispatched → Delivered
```

- New orders and new enquiries are created with `Enquiry Received`.
- The admin queue can advance the status via `PATCH /api/admin/orders/{id}` or `/api/admin/enquiries/{id}`.
- The customer app renders the whole pipeline on the detail screen and highlights the current stage with a red timeline dot.

---

## 8. Cart, checkout & bulk enquiry

- Cart lives entirely in React state (`useState`) inside `app/index.tsx` — not persisted server-side.
- Each cart line stores the product id, chosen variant, quantity, unit price snapshot.
- `PROCEED TO ORDER` POSTs to `/api/orders` with `{ items, customer_name, business_name, mobile, total }`. Auth required — the buyer is prompted to sign in if not authenticated.
- `WHATSAPP ENQUIRY` on any product opens `https://wa.me/<settings.whatsapp>?text=<encoded>` in the OS.
- The dedicated bulk enquiry form is available signed-in or anonymously; it also honours the admin WhatsApp number.

---

## 9. Frontend structure inside `app/index.tsx`

Everything lives in a single file so the whole app can be reasoned about as one state machine. Notable sections:

- **Design tokens & styles** — `useStyles()` returns a themed `StyleSheet`. Colors come from `src/theme.ts`; no hex literals in components.
- **API layer** — imported from `@/src/haidar-api` (`api()`, `money()`, `whatsappLink()`, and typed `Product`, `Variant`, `Order`, `Enquiry`, `Settings`).
- **Persistent auth** — customer + admin tokens are hydrated from `storage` on boot inside the initial `useEffect`.
- **Tabs** — `HOME | PRODUCTS | ENQUIRY | ORDERS | PROFILE`. Tapping `ENQUIRY` or `ORDERS` while unauthenticated opens the OTP sheet and remembers `pendingTab` so the user lands on the intended tab after login.
- **Detail views** — Product detail, Cart, Order/Enquiry detail all replace `main`; the bottom nav and floating cart hide while any detail view is open.
- **Admin control room** — appears when `tab === "admin"` and `adminToken` is set; contains four sub-tabs (Products / Orders / Enquiries / Settings). Adding/deleting a product hits `/api/admin/products` and then reloads the public catalogue so buyers see the change immediately.

`_layout.tsx` includes an asset-prewarm effect for `@expo/vector-icons` — **do not remove it**, it fixes Android/Expo Go icon flicker.

---

## 10. WhatsApp integration

- Store the sales number in `settings.whatsapp` **without** the `+` or spaces (e.g. `919812345678`).
- Every WhatsApp CTA in the app calls `whatsappLink(settings.whatsapp, message)` which produces `https://wa.me/<num>?text=<encoded>`.
- Admins change the number from Admin → Settings; buyers pick up the new number on their next catalogue refresh.

---

## 11. Image / upload handling

Product images are text-only cards today — `products.image_data` is reserved for a future upload flow. The intended shape is an array of public HTTPS URLs. When you wire the upload, keep the admin write path inside `/api/admin/products` and stash URLs (not blobs) so Mongo docs stay small.

---

## 12. Local development setup

### Prerequisites
- Node.js **20.x** and `yarn` (the repo pins `yarn@1` via `packageManager` in `package.json` when present)
- Python **3.11**
- MongoDB **6 or 7** running locally (`brew install mongodb-community` / `docker run -p 27017:27017 mongo:7`)
- The Expo Go app on a real device (optional, for phone preview)

### Backend
```bash
cd backend
python3.11 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.template .env      # fill MONGO_URL, DB_NAME, JWT_SECRET, ADMIN_EMAIL, ADMIN_PASSWORD
uvicorn server:app --host 0.0.0.0 --port 8001 --reload
```

The first startup will (a) seed the products + business settings, (b) create the `admins` unique index, and (c) insert one admin using `ADMIN_EMAIL` / `ADMIN_PASSWORD` (or a random password logged to stdout).

### Frontend
```bash
cd frontend
yarn install
cp .env.template .env      # set EXPO_PUBLIC_BACKEND_URL=http://localhost:8001
yarn start                 # opens Expo Dev Tools
```

Press `w` for web, scan the QR with Expo Go for mobile, or use an iOS/Android simulator.

### Running tests
```bash
cd backend
pytest -q                  # 38 tests across backend_test.py + test_admin_auth.py
```

---

## 13. Production deployment

You have two supported paths.

### A. Emergent-managed deploy (preview → production)
1. Click **Publish** (top-right in the Emergent UI) → **Deploy your app**.
2. Emergent copies every `.env` key you have in preview to the deployment secret store on first deploy (that's why `.env` files are populated locally but never committed). On subsequent deploys existing secrets are preserved — edit them from the Deployment panel.
3. Generate iOS + Android builds from the same Publish panel. `eas.json` is Emergent-managed; do not touch it.
4. Native-only features (real SMS OTP, push notifications) only work in the generated build, not in Expo Go.

### B. Self-host (any cloud)
1. Provision MongoDB (Atlas / self-hosted). Get a connection string.
2. Deploy the backend behind HTTPS. Any Uvicorn/Gunicorn host works — Railway, Fly.io, Render, an EC2 with `systemd`, a Kubernetes Deployment (`uvicorn server:app --host 0.0.0.0 --port 8001`).
3. Front the API with a reverse proxy that keeps the `/api/*` path prefix (or rewrites it) so the frontend does not need to change.
4. Provide the backend with the env vars in `backend/.env.template`.
5. Build the mobile client:
   ```bash
   cd frontend
   yarn install --frozen-lockfile
   npx expo prebuild            # creates ios/ and android/ folders
   eas build --platform all     # or your own Fastlane / Gradle / Xcode pipeline
   ```
   Set `EXPO_PUBLIC_BACKEND_URL` to the public API URL **before** the build — Expo bakes `EXPO_PUBLIC_*` values into the JS bundle.
6. Submit to the App Store / Play Store, or distribute via TestFlight / Play internal testing.

### Suggested infra sizing (self-host)
- Backend: 1 vCPU / 512 MB RAM handles the current traffic pattern. Scale horizontally behind a load balancer once daily orders cross ~5k.
- MongoDB: any M10 (Atlas) or 2 GB VM. Add compound indexes on `orders.customer_id + created_at` and `enquiries.customer_id + created_at` when the tables grow past ~100k rows.
- Storage: none required today (no uploads).

---

## 14. Migrations & seeds

There is **no migration framework** — Mongo is schemaless and the app performs idempotent bootstrap in `@app.on_event("startup")`:
- Seeds the six starter products if `products` is empty.
- Seeds the `settings` doc if missing.
- Seeds one admin if `admins` is empty and creates the unique index.

To reset for a fresh demo:
```bash
mongosh <DB_NAME> --eval 'db.products.drop(); db.settings.drop(); db.admins.drop();'
# restart the backend — it will re-seed
```

To rotate the seeded admin password after go-live, either update the doc directly (`db.admins.updateOne({email:"…"}, {$set:{password_hash:"<new bcrypt hash>"}})`) or wipe the admins collection and set a new `ADMIN_PASSWORD` env before restart.

---

## 15. Known bugs & limitations

1. **Admin order/enquiry detail is list-only.** The customer app has a tappable detail screen with a 6-stage timeline, but the Admin Control Room currently shows orders and enquiries as summary rows without a detail view. Admins update status by hitting the `PATCH /api/admin/orders/{id}` endpoint directly (or from a future detail screen). Wire it up by re-using the customer `ActivityDetail` component and swapping the fetch call to `/api/admin/orders/{id}` (add this route — it is not yet implemented).
2. **`sales_response` on the enquiry admin UI**: the field exists in Mongo and the model but the admin form for editing it is not present. The read side already renders it in the customer's enquiry detail.
3. **OTP is mocked.** Any 4-digit code passes. A real SMS provider (MSG91 / Twilio / Kaleyra) must be wired before public launch.
4. **No pagination on admin queues.** `/api/admin/products`, `/api/admin/orders`, `/api/admin/enquiries` return everything. Add `page`/`page_size` when the queue exceeds ~500 rows.
5. **Cart is per-device.** It lives in React state; if the buyer swaps devices before checkout, the cart is lost. Persist to `storage` if desired.
6. **Passlib startup warning.** With bcrypt 4.x + passlib 1.7.4 you'll see `error reading bcrypt version` once at startup — harmless, hashing/verification is unaffected.
7. **No image upload path yet.** `products.image_data` is reserved; the admin form is text-only.

---

## 16. Business rules & decisions worth preserving

- **Palette is non-negotiable.** Red `#D21414` + Black `#111111` on white. No blues/purples/greens/pastels.
- **Wholesale-first copy.** Hero says “Direct from factory”. Never claim “lowest price” or “best quality in India” — the brief bans unsupported superlatives.
- **MOQ is per variant, not per product.** Enforce on the client (`quantity >= variant.moq`) — the backend does not currently reject sub-MOQ orders, so add that guard in `/api/orders` when you add pagination/payments.
- **Prices are in INR (₹) with no decimals.** The `money()` helper renders `₹8,160` — keep that formatter.
- **Guest bulk enquiry is allowed.** Contact-form submissions do not require login; the app still records them in `enquiries` with `customer_id: ""`. Admins call the customer back on the WhatsApp number provided.
- **Admin does not manage inventory numerically today.** `variant.stock` is a display-only number; there is no reservation on order placement.
- **All timestamps are ISO 8601 in UTC.** Use `now_iso()` when adding new writes.

---

## 17. Third-party services to configure before launch

- **Real SMS provider** for OTP: MSG91, Twilio Verify, or Kaleyra. Replace the body of `/api/auth/request-otp` and `/api/auth/verify-otp`. Store the sent code in `otp_codes` with a TTL index (`{ createdAt: 1 }, expireAfterSeconds: 300`).
- **Payment gateway** when you enable prepaid orders: Razorpay for domestic INR B2B, Stripe if you plan international. The data model already carries `orders.total` so no schema change is needed.
- **Object storage** for product images: Emergent Managed Object Storage on Emergent, or S3/Cloudflare R2 self-hosted. Push public URLs into `products.image_data`.
- **Email**: Resend (Emergent-managed) or SendGrid for order confirmations. Trigger from the `POST /api/orders` handler.
- **Push notifications**: Emergent-managed push or Firebase Cloud Messaging. Only viable in a real build, not Expo Go.

None of these are wired today; the code is structured so each one is an isolated additive change.

---

## 18. Env & secret hygiene

- `.env` is git-ignored (`/app/.gitignore`). Never commit real values.
- Secrets never appear in the frontend bundle — the only public value is `EXPO_PUBLIC_BACKEND_URL`.
- Rotate `JWT_SECRET` on every environment. Rotating it invalidates all existing customer + admin tokens (they'll have to sign in again).
- The seeded admin password is written once to `/app/memory/test_credentials.md`. **Delete that file after handover** or move it to your secret manager.

---

## 19. What to change first if you continue building

1. Add an Admin Order/Enquiry **detail screen** (mirrors the customer detail) and a status dropdown so the sales team can advance the pipeline in one tap. This is the biggest current UX gap.
2. Wire a real SMS provider so OTP is not a mock.
3. Add product image upload from the admin panel.
4. Add MOQ + stock enforcement in `POST /api/orders`.
5. Paginate admin queues.
6. Enable Razorpay (or Stripe with Crypto) so buyers can prepay a percentage of the order.

---

## 20. Handover checklist

- [x] Frontend + backend source code included as-is.
- [x] `.env.template` files added; real `.env` files intentionally excluded.
- [x] `test_credentials.md` intentionally excluded from the export (contains a plaintext password).
- [x] MongoDB schema documented (§4) and seed logic explained (§14).
- [x] Auth flows documented (customer OTP §5, admin §5, JWT payload §5).
- [x] All endpoints documented with methods and auth requirements (§6).
- [x] Known bugs listed (§15) — in particular the admin order-detail gap.
- [x] Deploy playbooks for both Emergent-managed and self-host paths (§13).
- [x] No secrets, tokens, or API keys are present in this handover.

If you get stuck, start by reading `backend/server.py` top-to-bottom (it is deliberately a single file) and then `frontend/app/index.tsx`. Every business rule the app relies on lives in those two files.
