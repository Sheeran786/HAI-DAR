"""Admin auth regression: DB-seeded bcrypt admin, timing-safe login, protected routes."""
import os
import pytest
import requests

BASE_URL = os.environ["EXPO_BACKEND_URL"].rstrip("/") if os.environ.get("EXPO_BACKEND_URL") else "https://haidar-wholesale.preview.emergentagent.com"
API = f"{BASE_URL}/api"

ADMIN_EMAIL = "admin@haidartools.in"
ADMIN_PASSWORD = os.environ.get("ADMIN_TEST_PASSWORD", "YOUR_ADMIN_TEST_PASSWORD_HERE")


@pytest.fixture(scope="module")
def s():
    session = requests.Session()
    session.headers.update({"Content-Type": "application/json"})
    return session


# ----- admin login -----
class TestAdminLogin:
    def test_success_returns_token_and_role(self, s):
        r = s.post(f"{API}/auth/admin-login",
                   params={"email": ADMIN_EMAIL, "password": ADMIN_PASSWORD})
        assert r.status_code == 200, r.text
        body = r.json()
        assert isinstance(body.get("token"), str) and len(body["token"]) > 10
        assert body.get("role") == "admin"

    def test_wrong_password_401_generic(self, s):
        r = s.post(f"{API}/auth/admin-login",
                   params={"email": ADMIN_EMAIL, "password": "not-the-password"})
        assert r.status_code == 401
        assert r.json().get("detail") == "Incorrect email or password"

    def test_unknown_email_same_generic_401(self, s):
        r = s.post(f"{API}/auth/admin-login",
                   params={"email": "unknown@example.com", "password": ADMIN_PASSWORD})
        assert r.status_code == 401
        assert r.json().get("detail") == "Incorrect email or password"

    def test_case_insensitive_email(self, s):
        r = s.post(f"{API}/auth/admin-login",
                   params={"email": ADMIN_EMAIL.upper(), "password": ADMIN_PASSWORD})
        assert r.status_code == 200, r.text
        assert r.json().get("role") == "admin"

    def test_empty_password_401(self, s):
        r = s.post(f"{API}/auth/admin-login",
                   params={"email": ADMIN_EMAIL, "password": ""})
        assert r.status_code == 401


# ----- protected routes -----
@pytest.fixture(scope="module")
def admin_token(s):
    r = s.post(f"{API}/auth/admin-login",
               params={"email": ADMIN_EMAIL, "password": ADMIN_PASSWORD})
    assert r.status_code == 200, r.text
    return r.json()["token"]


@pytest.fixture(scope="module")
def customer_token(s):
    r = s.post(f"{API}/auth/verify-otp",
               params={"mobile": "9000009999", "code": "1234"})
    assert r.status_code == 200, r.text
    return r.json()["token"]


ADMIN_ROUTES = [
    ("GET", "/admin/products"),
    ("GET", "/admin/orders"),
    ("GET", "/admin/enquiries"),
]


class TestAdminRouteAuth:
    @pytest.mark.parametrize("method,path", ADMIN_ROUTES)
    def test_admin_token_accepted(self, s, admin_token, method, path):
        r = s.request(method, f"{API}{path}",
                      headers={"Authorization": f"Bearer {admin_token}"})
        assert r.status_code == 200, r.text
        assert isinstance(r.json(), list)

    @pytest.mark.parametrize("method,path", ADMIN_ROUTES)
    def test_customer_token_forbidden_403(self, s, customer_token, method, path):
        r = s.request(method, f"{API}{path}",
                      headers={"Authorization": f"Bearer {customer_token}"})
        assert r.status_code == 403, r.text

    @pytest.mark.parametrize("method,path", ADMIN_ROUTES)
    def test_anonymous_401(self, s, method, path):
        r = s.request(method, f"{API}{path}")
        assert r.status_code == 401, r.text

    def test_admin_settings_patch_accepts_admin(self, s, admin_token):
        r = s.patch(f"{API}/admin/settings",
                    json={"delivery_info": "TEST_ delivery info"},
                    headers={"Authorization": f"Bearer {admin_token}"})
        assert r.status_code == 200, r.text
        assert r.json().get("delivery_info") == "TEST_ delivery info"

    def test_admin_settings_patch_forbidden_for_customer(self, s, customer_token):
        r = s.patch(f"{API}/admin/settings",
                    json={"delivery_info": "should not apply"},
                    headers={"Authorization": f"Bearer {customer_token}"})
        assert r.status_code == 403

    def test_admin_settings_patch_anonymous_401(self, s):
        r = s.patch(f"{API}/admin/settings", json={"delivery_info": "x"})
        assert r.status_code == 401


# ----- Product create → visible in public catalogue (proves same DB) -----
class TestAdminWritesReflectInPublicCatalogue:
    def test_create_admin_product_appears_in_public_list(self, s, admin_token):
        h = {"Authorization": f"Bearer {admin_token}"}
        payload = {
            "name": "TEST_Public Visibility Hammer",
            "category": "TestVis",
            "sku": "TEST-VIS-001",
            "description": "visibility test",
            "specifications": ["spec"],
            "packaging": "carton",
            "delivery": "3 days",
            "image_data": [],
            "variants": [{"label": "STD", "sku": "TEST-VIS-STD", "moq": 10, "wholesale_price": 100, "stock": 5}],
            "featured": False, "is_new": True, "active": True, "badge": "",
        }
        r = s.post(f"{API}/admin/products", json=payload, headers=h)
        assert r.status_code == 200, r.text
        pid = r.json()["id"]
        try:
            r2 = s.get(f"{API}/products", params={"search": "TEST_Public Visibility"})
            assert r2.status_code == 200
            names = [p["name"] for p in r2.json()["items"]]
            assert "TEST_Public Visibility Hammer" in names, f"created product not in public catalogue: {names}"
        finally:
            s.delete(f"{API}/admin/products/{pid}", headers=h)


# ----- Admins collection integrity -----
class TestAdminSeed:
    def test_exactly_one_admin_seeded(self, s):
        # We cannot query Mongo directly here, but we can verify the seeded admin can log in
        # and that a second login attempt does not "reset" state (idempotent).
        r1 = s.post(f"{API}/auth/admin-login",
                    params={"email": ADMIN_EMAIL, "password": ADMIN_PASSWORD})
        r2 = s.post(f"{API}/auth/admin-login",
                    params={"email": ADMIN_EMAIL, "password": ADMIN_PASSWORD})
        assert r1.status_code == 200 and r2.status_code == 200
