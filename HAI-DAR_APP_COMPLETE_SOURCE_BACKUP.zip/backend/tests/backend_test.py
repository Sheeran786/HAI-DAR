"""HAI-DAR wholesale backend regression tests focused on the 4-digit OTP change."""
import os
import pytest
import requests

BASE_URL = os.environ.get("EXPO_BACKEND_URL", "https://haidar-wholesale.preview.emergentagent.com").rstrip("/")
API = f"{BASE_URL}/api"
ADMIN_EMAIL = "admin@haidartools.in"
ADMIN_PASSWORD = os.environ.get("ADMIN_TEST_PASSWORD", "YOUR_ADMIN_TEST_PASSWORD_HERE")


@pytest.fixture(scope="session")
def s():
    session = requests.Session()
    session.headers.update({"Content-Type": "application/json"})
    return session


@pytest.fixture(scope="session")
def admin_token(s):
    r = s.post(f"{API}/auth/admin-login",
               params={"email": ADMIN_EMAIL, "password": ADMIN_PASSWORD})
    assert r.status_code == 200, r.text
    return r.json()["token"]


@pytest.fixture(scope="session")
def customer(s):
    mobile = "9876543210"
    r = s.post(f"{API}/auth/verify-otp", params={"mobile": mobile, "code": "1234"})
    assert r.status_code == 200, r.text
    data = r.json()
    return {"token": data["token"], "user": data["user"], "mobile": mobile}


def test_root(s):
    r = s.get(f"{API}/")
    assert r.status_code == 200


class TestRequestOtp:
    def test_valid_mobile_returns_dev_code(self, s):
        r = s.post(f"{API}/auth/request-otp", params={"mobile": "9876543210"})
        assert r.status_code == 200
        assert r.json().get("dev_code") == "1234"

    def test_strips_non_digits(self, s):
        r = s.post(f"{API}/auth/request-otp", params={"mobile": "+91-98765 43210"})
        assert r.status_code == 200
        assert r.json().get("dev_code") == "1234"

    def test_short_mobile_400(self, s):
        r = s.post(f"{API}/auth/request-otp", params={"mobile": "99"})
        assert r.status_code == 400
        assert "valid mobile" in r.json().get("detail", "").lower()


class TestVerifyOtp:
    @pytest.mark.parametrize("code", ["1234", "0000", "5678", "9999"])
    def test_any_4_digit_ok(self, s, code):
        r = s.post(f"{API}/auth/verify-otp",
                   params={"mobile": "9000000001", "code": code})
        assert r.status_code == 200, r.text
        body = r.json()
        assert "token" in body and "user" in body
        assert body["user"]["mobile"] == "9000000001"

    def test_reject_6_digit(self, s):
        r = s.post(f"{API}/auth/verify-otp",
                   params={"mobile": "9876543210", "code": "123456"})
        assert r.status_code == 401
        assert "4-digit" in r.json()["detail"]

    def test_reject_letters(self, s):
        r = s.post(f"{API}/auth/verify-otp",
                   params={"mobile": "9876543210", "code": "abcd"})
        assert r.status_code == 401

    def test_reject_empty(self, s):
        r = s.post(f"{API}/auth/verify-otp",
                   params={"mobile": "9876543210", "code": ""})
        assert r.status_code == 401

    def test_reject_3_digit(self, s):
        r = s.post(f"{API}/auth/verify-otp",
                   params={"mobile": "9876543210", "code": "123"})
        assert r.status_code == 401

    def test_short_mobile_400(self, s):
        r = s.post(f"{API}/auth/verify-otp",
                   params={"mobile": "99", "code": "1234"})
        assert r.status_code == 400

    def test_idempotent_customer_id(self, s):
        m = "9111111222"
        r1 = s.post(f"{API}/auth/verify-otp", params={"mobile": m, "code": "1234"})
        r2 = s.post(f"{API}/auth/verify-otp", params={"mobile": m, "code": "5678"})
        assert r1.status_code == 200 and r2.status_code == 200
        assert r1.json()["user"]["id"] == r2.json()["user"]["id"]


class TestProducts:
    def test_list_products(self, s):
        r = s.get(f"{API}/products")
        assert r.status_code == 200
        data = r.json()
        assert isinstance(data["items"], list)
        assert len(data["items"]) >= 1
        assert "_id" not in data["items"][0]

    def test_admin_crud(self, s, admin_token):
        h = {"Authorization": f"Bearer {admin_token}"}
        payload = {
            "name": "TEST_Regression Tool",
            "category": "TestCat",
            "sku": "TEST-REG-001",
            "description": "regression",
            "specifications": ["spec1"],
            "packaging": "carton",
            "delivery": "3 days",
            "image_data": [],
            "variants": [{"label": "STD", "sku": "TEST-STD", "moq": 10, "wholesale_price": 100, "stock": 5}],
            "featured": False, "is_new": True, "active": True, "badge": ""
        }
        r = s.post(f"{API}/admin/products", json=payload, headers=h)
        assert r.status_code == 200, r.text
        pid = r.json()["id"]

        r2 = s.get(f"{API}/products/{pid}")
        assert r2.status_code == 200
        assert r2.json()["name"] == "TEST_Regression Tool"

        r3 = s.patch(f"{API}/admin/products/{pid}",
                     json={"name": "TEST_Regression Tool Updated"}, headers=h)
        assert r3.status_code == 200
        assert r3.json()["name"] == "TEST_Regression Tool Updated"

        r4 = s.delete(f"{API}/admin/products/{pid}", headers=h)
        assert r4.status_code == 200 and r4.json().get("deleted")

        r5 = s.get(f"{API}/products/{pid}")
        assert r5.status_code == 404


class TestActivity:
    def test_order_and_detail(self, s, customer):
        h = {"Authorization": f"Bearer {customer['token']}"}
        payload = {
            "items": [{"product_id": "x", "name": "Test", "variant": "STD", "quantity": 5, "price": 100}],
            "customer_name": "Tester", "business_name": "TestBiz",
            "mobile": customer["mobile"], "total": 500
        }
        r = s.post(f"{API}/orders", json=payload, headers=h)
        assert r.status_code == 200
        oid = r.json()["id"]

        r2 = s.get(f"{API}/orders/{oid}", headers=h)
        assert r2.status_code == 200
        assert r2.json()["id"] == oid

    def test_enquiry_and_detail(self, s, customer):
        h = {"Authorization": f"Bearer {customer['token']}"}
        payload = {
            "customer_name": "Tester", "business_name": "TestBiz",
            "mobile": customer["mobile"], "whatsapp": customer["mobile"],
            "city": "Mumbai", "state": "MH",
            "product": "Sledge Hammer", "required_quantity": 100,
            "message": "TEST_ enquiry"
        }
        r = s.post(f"{API}/enquiries", json=payload, headers=h)
        assert r.status_code == 200
        eid = r.json()["id"]
        r2 = s.get(f"{API}/enquiries/{eid}", headers=h)
        assert r2.status_code == 200
        assert r2.json()["product"] == "Sledge Hammer"

    def test_detail_unauthenticated_401(self, s):
        r = s.get(f"{API}/orders/does-not-exist")
        assert r.status_code == 401
