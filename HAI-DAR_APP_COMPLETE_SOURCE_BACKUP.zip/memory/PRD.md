# HAI-DAR – Wholesale Hand Tools App (PRD)

## Overview
HAI-DAR is a mobile-first B2B wholesale ordering app for an Indian hand-tool factory brand. It lets hardware wholesalers, distributors and dealers browse the factory catalogue, add tools to a bulk cart, send bulk enquiries, and track orders. A protected admin panel powers the entire catalogue, business info and enquiry/order queues.

## Brand direction
- Colors: RED (`#D21414`) + BLACK (`#111111`) on white. No blue/purple/green/pastel.
- Feel: industrial, factory-direct, professional, bold, trustworthy.
- Wordmark logo (text-based) until the customer uploads an official asset via admin.

## Personas
- Wholesale buyer (customer): browses catalogue, adds to cart, sends enquiry, places bulk orders.
- Sales admin (admin): manages products, WhatsApp/business settings, orders and enquiries.

## Core screens (customer)
- Splash — black background with red rule, HAI-DAR wordmark, tagline "DIRECT FROM FACTORY".
- Home — hero, category chips, featured products, black CTA banner, "Why buy from HAI-DAR" trust grid.
- Products — search, category filter, sort, grid of product cards.
- Product detail — variant selector, quantity stepper, MOQ, specs, bulk callout, Add to cart / WhatsApp enquiry.
- Cart — quantity/remove editing, wholesale summary, Proceed to order.
- Bulk enquiry — full form (name, business, mobile, WA, city, state, product, quantity, message).
- Orders — merged view of customer orders + enquiries with status.
- Profile — customer info, menu, sign in / sign out, admin access entry.

## Admin panel
- Email + password sheet (separate from customer OTP flow).
- Tabs: Products (add / list / delete), Orders (queue), Enquiries (queue), Settings (WhatsApp number + business info preview).

## Tech stack
- Frontend: Expo Router (single index route + bottom tab bar via state), React Native 0.86, TypeScript, `@expo/vector-icons`.
- Backend: FastAPI + Motor (MongoDB async), JWT auth.
- Database: MongoDB (collections: `products`, `settings`, `customers`, `enquiries`, `orders`, `otp_codes`).

## API surface (all under `/api`)
- `GET /` — health.
- `GET /settings` — public business settings.
- `PATCH /admin/settings` — update business settings (admin).
- `GET /products` — public catalogue (search, category, sort, pagination).
- `GET /products/{id}` — public product detail.
- `GET|POST|PATCH|DELETE /admin/products` — full CRUD (admin).
- `POST /auth/request-otp` — dummy OTP (returns `dev_code`, always `123456`).
- `POST /auth/verify-otp` — issue customer JWT.
- `POST /auth/admin-login` — issue admin JWT.
- `GET|POST /enquiries` — customer enquiries.
- `GET|PATCH /admin/enquiries` — admin queue.
- `GET|POST /orders` — customer orders.
- `GET|PATCH /admin/orders` — admin queue.

## Authentication
- Customers: mobile OTP (dev mode returns `123456`).
- Admin: email + password from `/app/backend/.env` (`ADMIN_EMAIL` / `ADMIN_PASSWORD`).
- JWT stored in memory (14 day expiry). Role gate for `/api/admin/*`.

## WhatsApp integration
- Configurable phone number in `settings.whatsapp` (admin editable).
- Deep-links via `wa.me/<number>?text=<encoded>` on every enquiry CTA.

## Data model
- Product: `id, name, category, sku, description, specifications[], packaging, delivery, image_data[], variants[], featured, is_new, active, badge`.
- Variant: `id, label, sku, weight, moq, wholesale_price, stock`.
- Enquiry: `id, customer_id, customer_name, business_name, mobile, whatsapp, city, state, product, required_quantity, message, items[], status, sales_response, sales_notes, created_at`.
- Order: `id, customer_id, items[], customer_name, business_name, mobile, total, status, tracking, created_at`.
- Settings: `id: "business", whatsapp, phone, email, address, delivery_info, announcement`.

## Deferred / future scope
- Real SMS provider (MSG91 / Twilio) for OTP.
- Payment gateway (Stripe / Razorpay) — data model already stores totals.
- Invoicing + shipping integrations.
- Image upload from admin (currently placeholder text cards).
- Push notifications.
