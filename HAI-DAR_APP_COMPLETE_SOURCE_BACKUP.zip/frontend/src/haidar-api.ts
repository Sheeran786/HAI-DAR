import Constants from "expo-constants";

export type Variant = { id: string; label: string; sku: string; weight?: string; moq: number; wholesale_price?: number | null; stock: number };
export type Product = { id: string; name: string; category: string; sku: string; description: string; specifications: string[]; packaging: string; delivery: string; image_data: string[]; variants: Variant[]; featured: boolean; is_new: boolean; active: boolean; badge: string };
export type Settings = { id: string; whatsapp: string; phone: string; email: string; address: string; delivery_info: string; announcement: string };
export type Enquiry = { id: string; product: string; required_quantity: number; status: string; sales_response: string; sales_notes?: string; created_at: string; business_name: string; customer_name?: string; mobile?: string; whatsapp?: string; city?: string; state?: string; message?: string; items?: Array<{ name?: string; variant?: string; quantity?: number; price?: number | null }> };
export type Order = { id: string; items: Array<{ name: string; variant: string; quantity: number; price?: number | null; product_id?: string }>; total: number; status: string; created_at: string; tracking: string; customer_name?: string; business_name?: string; mobile?: string };

const extra = Constants.expoConfig?.extra as { backendUrl?: string } | undefined;
const baseUrl = extra?.backendUrl || process.env.EXPO_PUBLIC_BACKEND_URL || "";

export async function api<T>(path: string, options: RequestInit = {}, token?: string): Promise<T> {
  const response = await fetch(`${baseUrl}/api${path}`, {
    ...options,
    headers: { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}), ...(options.headers || {}) },
  });
  const body = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(body.detail || "Request failed");
  return body as T;
}

export function money(value?: number | null): string {
  return value == null ? "Get price" : `₹${Math.round(value).toLocaleString("en-IN")}`;
}

export function whatsappLink(number: string, message: string): string {
  const normalized = number.replace(/\D/g, "");
  return `https://wa.me/${normalized}?text=${encodeURIComponent(message)}`;
}